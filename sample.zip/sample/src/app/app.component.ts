import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<h1 style="text-align:center">Hello {{name}}</h1>



<div class="row">
 <img src="{{imgUrl}}" width="100%">

</div>



<h1 style="text-align:center">  About Us   </h1>
<div class="container">
<div class="row">


<div class="col-md-6 pad">
 <img src="{{imgUrl}}" width="100%">

 </div>

 <div class="col-md-6 pad">

 <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
 <button class="btn btn-primary"> Submit</button>
 </div>

 </div>
</div>




<h1  style="text-align:center">  Products  </h1>
<div class="container">
<div class="row">



<div class="col-md-4">
 <img src="{{imgUrl}}" width="100%">
 <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
 <button class="btn btn-primary"> Submit</button>
 </div>

 <div class="col-md-4">
 <img src="{{imgUrl}}" width="100%">
 <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
 <button class="btn btn-primary"> Submit</button>
 </div>

 <div class="col-md-4">
 <img src="{{imgUrl}}" width="100%">
 <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
 <button class="btn btn-primary"> Submit</button>
 </div>
 </div>
</div>



<h1  style="text-align:center">  Contact Us  </h1>
<div class="container pad">

<div class="row">
<div class="col-md-2"></div>
<div class="col-md-8">
<form>
<div class="form-group">
<input type="text" class="form-control">
</div>

<div class="form-group">
<input type="text" class="form-control">
</div>

<div class="form-group">
<input type="text" class="form-control">
</div>
<button class="btn btn-primary"> Submit</button>
</form>
</div>
<div class="col-md-2"></div>
</div>
</div>



  `

})
export class AppComponent  { name = 'Angular';
imgUrl="https://nareshit.com/wp-content/uploads/2018/08/angular-JS-online-training-nareshit.jpg";


 }
